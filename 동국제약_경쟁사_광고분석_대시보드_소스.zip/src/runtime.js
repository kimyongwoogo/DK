/* 파일로 열 때 대시보드 플랫폼의 dash.* 기능을 대신하는 작은 실행기.
   데이터는 페이지 안 <script id="dash-data">의 JSON에서 읽고, calcs.js의 계산과 app.js의 그리기를 그대로 돌립니다. */
(function () {
  const DATA = JSON.parse(document.getElementById('dash-data').textContent);
  const calcs = {};
  const draws = {};
  const listeners = [];
  const cache = {};
  let params = {};
  let ready = false;
  const get = (id) => {
    if (Object.prototype.hasOwnProperty.call(DATA, id)) return DATA[id];
    if (Object.prototype.hasOwnProperty.call(cache, id)) return cache[id];
    const c = calcs[id];
    if (!c) throw new Error('알 수 없는 데이터: ' + id);
    cache[id] = c.fn(...c.inputs.map(get));
    return cache[id];
  };
  const runDraw = (name) => {
    const fn = draws[name];
    if (!fn) return;
    document.querySelectorAll('[data-draw="' + name + '"]').forEach((el) => {
      try { fn(el); } catch (e) { console.error(name, e); }
    });
  };
  const runAll = () => {
    listeners.forEach((f) => { try { f(); } catch (e) { console.error(e); } });
    Object.keys(draws).forEach(runDraw);
  };
  window.dash = {
    calc: (id, o) => { calcs[id] = o; },
    data: (id) => {
      try { return { status: 'ok', data: get(id) }; } catch (e) { console.error(e); return { status: 'error', data: null }; }
    },
    draw: (name, fn) => {
      if (fn) { draws[name] = fn; if (ready) runDraw(name); } else if (ready) runDraw(name);
    },
    onData: (fn) => { listeners.push(fn); if (ready) fn(); },
    params: () => params,
    setParams: (p) => {
      Object.keys(p).forEach((k) => { if (p[k] === null || p[k] === undefined) delete params[k]; else params[k] = p[k]; });
      runAll();
    },
    setLink: (name) => { try { history.replaceState(null, '', '#' + name); } catch (e) { /* 파일에서는 무시 */ } },
    colors: ['#2563eb', '#0d9488', '#f59e0b', '#a855f7', '#0ea5e9', '#22c55e', '#f97316', '#db2777'],
  };
  window.__dashStart = () => { ready = true; runAll(); };
  document.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.tv-tab')) setTimeout(runAll, 0); });
  let t = null;
  window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(runAll, 200); });
})();
